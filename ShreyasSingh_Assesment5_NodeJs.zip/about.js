var express = require("express");

var app = express();
app.set("view engine", "ejs");

var fs = require("fs");
var fileData = fs.readFileSync("./resources/about.txt", "utf8");
console.log(fileData);

app.get("/", function (request, response) {
    response.send("<h1>Please add '/about' to the link to view About Us page</h1>");
});
app.get("/about", function (request, response) {
    response.render("about", { data: fileData });
});

console.log("Server started on port: 2999");

app.listen(2999);
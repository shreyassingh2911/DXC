package com.dxc.pms.model;

import javax.persistence.Embeddable;

@Embeddable
public class Hospital {

	private String hospitalName;
	private String hospitalCity;
	
	public Hospital() {
		// TODO Auto-generated constructor stub
	}

	public Hospital(String hospitalName, String hospitalCity) {
		super();
		this.hospitalName = hospitalName;
		this.hospitalCity = hospitalCity;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getHospitalCity() {
		return hospitalCity;
	}

	public void setHospitalCity(String hospitalCity) {
		this.hospitalCity = hospitalCity;
	}

	@Override
	public String toString() {
		return "Hospital [hospitalName=" + hospitalName + ", hospitalCity=" + hospitalCity + "]";
	}
	
	
}

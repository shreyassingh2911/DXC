package com.dxc.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.pms.dao.ProductDAO;
import com.dxc.pms.model.Product;
import com.dxc.pms.service.ProductService;


@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	ProductService productService;
	//all products
	@GetMapping
	public List<Product>getAllProducts(){
		System.out.println("Fetching All Products");
		return productService.getProducts();
	}
	//1 product
	@GetMapping("/{productId}")
	public Product getProduct(@PathVariable("productId") int productId) {
		System.out.println("Get product1 called "+productId);
		return productService.getProduct(productId);
	}
	//delete
	@DeleteMapping("/{productId}")
	public boolean deleteProduct(@PathVariable("productId") int productId) {
		System.out.println("Delete product1 called "+productId);
		return productService.deleteProduct(productId);
	}
	
	
	//save
	@PostMapping()
	public boolean saveProduct(@RequestBody Product product) {
		System.out.println("Saving a product called ");
		System.out.println(product);
		return productService.addProduct(product);
	}
	//update
	@PutMapping()
	public boolean updateProduct(@RequestBody Product product) {
		System.out.println("Updating a product called");
		System.out.println(product);
		return productService.updateProduct(product);
	}
	
}
	
//	@RequestMapping("/getProduct/{productId}")
//	public Product getProduct(@PathVariable("productId")int productId) {
//		
//		System.out.println("Get Product 1 called "+productId);
//		return productService.getProduct(productId);
//	}
//	@RequestMapping("/getProduct/{productId}/orders/{oId}")
//	public Product getProduct2(@PathVariable("productId")int productId, @PathVariable("oId")int orderId) {
//		System.out.println("Get product 2 called "+productId+"order Id "+orderId);
//		return productService.getProduct(productId);
//	}

	






//	@RequestMapping("/productSave")
//	public ModelAndView productSave(Product product) {
//		System.out.println("Inside Controller "+product);
//		
//		productService.addProduct(product);
//		return new ModelAndView("productSave1","pr",product);
//	}


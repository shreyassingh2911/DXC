package com.dxc.pms.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.dxc.pms.model.Product;
import com.mongodb.WriteResult;

@Repository
public class ProductDAOImpl implements ProductDAO {
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	@Override
	public boolean addProduct(Product product) {
		
		
		System.out.println("This is from DAO"+product);
		mongoTemplate.save(product);
		return false;
	}
	
	@Override
	public Product getProduct(int productId) {
		Product product = new Product(100, "Phone", 29, 13434);
		mongoTemplate.findById(productId, Product.class, "product");
		return product;
	}
	@Override
	public boolean isProductExist(int productId) {
		Product product = mongoTemplate.findById(productId, Product.class, "product");
		if(product==null)
			return false;
		else
		return true;
	}
	@Override
	public boolean deleteProduct(int productId) {
		Product product = new Product();
		product.setProductId(productId);
		WriteResult writeResult = mongoTemplate.remove(product);
		System.out.println(writeResult);
		int rowsAffected = writeResult.getN();
		if(rowsAffected == 0)
			return false;
		else
			return true;
	}
	@Override
	public boolean updateProduct(Product product) {
		mongoTemplate.save(product);
		return false;
	}
	@Override
	public List<Product> getProducts() {	
		System.out.println("Getting product");
		return mongoTemplate.findAll(Product.class);
	}
	@Override
	public List<Product> searchProductByName(String productName) {
		// TODO Auto-generated method stub
		return null;
	}
	

}

package Assesment;

public class StringModification {
	public static void main(String[] args) {
		
	String s="The quick brown fox jumps over the lazy dog";
	String s2 = "The quick brown Fox jumps over the lazy Dog";
	String s3="THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG";
	char ch=s.charAt(12);
	System.out.println("Character at 12 index :"+ch);
	System.out.println(s.contains("is"));
	String s1 = s.concat(" and killed it");
	System.out.println(s1);
	System.out.println(s.endsWith("dogs"));
	System.out.println(s.equals(s2));
	System.out.println(s.equals(s3));
	System.out.println(s.length());
	System.out.println(s.matches("The quick brown Fox jumps over the lazy Dog"));
	String replStr=s.replace("The","A");
	System.out.println(replStr);
	 String[] arr = s.split("x", 0);  
     for (String w : arr) {  
         System.out.println(w);  
     }  
     System.out.println(s.substring(16,19));
     System.out.println(s.substring(40,43));
     System.out.println(s.toLowerCase());
     System.out.println(s.toUpperCase());
     System.out.println(s.indexOf("a"));
     System.out.println(s.lastIndexOf("e"));
	}
		
	}
	



package com.dxcSel;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
public class EnterMobileNo {
	public static WebDriver driver;
public static void main(String[] args) {

driver=new ChromeDriver();
driver.get("http://msn.com");
driver.manage().window().maximize();
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
WebDriverWait wait = new WebDriverWait(driver, 20);
driver.findElement(By.id("cp_inputTemplate")).sendKeys("9876543210");
driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
driver.switchTo().window(tabs.get(1));
driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/span/span")).click();
driver.close();
driver.switchTo().window(tabs.get(0));
driver.findElement(By.id("a"));
driver.close();
}

}

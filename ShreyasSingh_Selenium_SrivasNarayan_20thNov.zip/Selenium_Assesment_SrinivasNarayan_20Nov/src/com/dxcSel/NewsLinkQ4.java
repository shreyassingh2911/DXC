package com.dxcSel;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class NewsLinkQ4 {
public static WebDriver driver;
public static void main(String[] args) {
driver=new ChromeDriver();
driver.get("http://yahoo.com/");
driver.manage().window().maximize();
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
 
driver.findElement(By.id("#atomic")); 
WebElement links = driver.findElement(By.id("#atomic")); 
System.out.println(links.getSize());
 
 
 
System.out.println("News links are present on the site");
 }
 
}
 
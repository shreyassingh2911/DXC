import React, { Component } from "react";
import ProductDisplay from "./ProductDisplay";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import ProductDetails from "../routingDemo/ProductDetails";
import "./../../node_modules/bootstrap/dist/css/bootstrap.css";
class ProductList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      productId: "",
      quantity: "",
      errors: ""
    };
  }
  doValidation = ourData => {
    ourData.preventDefault();
    this.setState({
      productId: ourData.target.value,
      quantity: ourData.target.value
    });

    console.log(this.state.quantity);
  };

  doSubmit = ourData => {
    ourData.preventDefault();
    if (this.state.quantity == "" || this.state.quantity == 0) {
      this.setState({
        errors: "Quantity can't be Zero"
      });
    } else if (this.state.quantity < 0)
      this.setState({
        errors: "Quantity can't be negative"
      });
    else {
      this.setState({
        errors: ""
      });
      var arr = this.state.productList;
      arr[]
    }
  };
      // updateComment(newtext, this.state.productId);
    // {
    //   console.log("updating " + );
    //   var arr = this.state.comments;
    //   arr[i] = newtext;
    //   this.setState({ comments: arr });
    // }
  render() {
    const productList = [
      {
        productId: 1001,
        productName: "Watch",
        quantityOnHand: 2000,
        price: 10000
      },
      {
        productId: 1002,
        productName: "Mouse",
        quantityOnHand: 29,
        price: 180000
      },
      {
        productId: 1003,
        productName: "Laptop",
        quantityOnHand: 29,
        price: 122
      },
      {
        productId: 10113,
        productName: "Presenter",
        quantityOnHand: 29,
        price: 122
      },

      {
        productId: 111003,
        productName: "Marker",
        quantityOnHand: 29,
        price: 122
      }
    ];

    return (
      <div>
        <form className="form-group" onSubmit={this.doSubmit}>
          Product Id : <input type="text" className="form-control"></input>
          <br />
          Quantity:{" "}
          <input
            type="text"
            className="form-control"
            onChange={this.doValidation}
          ></input>
          <span className="alert-danger">{this.state.errors}</span>
          <br />
          <input type="submit"></input>
        </form>
        {productList.map((product, index) => (
          <Link to={`${this.props.match.url}/` + product.productName}>
            <ProductDisplay
              render={({ match }) => (match = { match })}
              nn={index}
              key={index}
              product={product}
            ></ProductDisplay>
          </Link>
        ))}

        <Route
          path={`${this.props.match.path}/:productName`}
          render={({ match }) => (match = { match })}
          component={ProductDetails}
        />
      </div>
    );
  }
}
export default ProductList;
import React, { Component } from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import "./../routingDemo/App.css";
import ProductList from "./ProductList";
import Home from "./Home";
export default class App extends Component {
  render() {
    return (
      <div className="mydiv">
        <Router>
          <div>
            <Link to="/">Home</Link>
            &nbsp; &nbsp; &nbsp; &nbsp;
            <Link to="/productList">ProductList</Link>
            &nbsp; &nbsp; &nbsp; &nbsp;
            <hr />
            <Route exact path="/" component={Home} />
            <Route
              path="/productList"
              render={({ match }) => (match = { match })}
              component={ProductList}
            />
          </div>
        </Router>
      </div>
    );
  }
}